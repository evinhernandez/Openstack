Set-DnsClientServerAddress -InterfaceAlias "team0" -ServerAddresses "10.13.0.51","10.240.10.33"
