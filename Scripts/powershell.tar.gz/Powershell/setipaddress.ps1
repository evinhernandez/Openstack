 New-NetIPAddress -InterfaceAlias "team0" -AddressFamily ipv4 -IPAddress 10.240.16.44 -Default
Gateway 10.240.16.1 -PrefixLength 23
