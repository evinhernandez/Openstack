Add-Computer -domainname hosting.ad.viacom.com -OUPath "OU=TestStaging,OU=OpenStack_Havana,OU=Flux,OU=Internet,OU=*Servers,DC=hosting,DC=ad,DC=viacom,DC=com" -cred mtvn\pesetskp -passthru –verbose 
