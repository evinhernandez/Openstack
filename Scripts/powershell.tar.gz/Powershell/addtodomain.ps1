Add-Computer -domainname hosting.ad.viacom.com -OUPath "OU=Openstack_Havana,OU=Internet,OU=*Servers,DC=hosting,DC=ad,DC=viacom,DC=com" -cred mtvn\hernandev -passthru –verbose
